class TransactionModel {

  final int id;
  final String name;
  final int price;
  final String type;
  final String currency;

  TransactionModel({this.id, this.name, this.price, this.type, this.currency});
}
